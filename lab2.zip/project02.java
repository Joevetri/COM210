/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

/**
 *
 * @author nygia_luescc0
 */
public class project02 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // 10 elem array
        int[] smallForUnsorted = {0,1,2,3,4,5,6,7,8,9};
        
        //100 elem array, for loop to produce values
        int[] mediumForUnsorted = new int[100];
        for(int i = 0; i < mediumForUnsorted.length; i++){
            mediumForUnsorted[i] = i;
        }
        //1000 elem array, for loop to produce values
        int[] largeForUnsorted = new int[1000];
         for(int i = 0; i < largeForUnsorted.length; i++){
            largeForUnsorted[i] = i;
        }
        
        // 10 elem array with null/0 values at end
        int[] smallNullsForUnsorted = new int[10];
        int k = 1;
        for(int i = 0; i < smallNullsForUnsorted.length-3; i++){ 
            smallNullsForUnsorted[i] = k;
            k++;
            
            
        }
        //100 elem array with null/0 values at end
        int[] mediumNullsForUnsorted = new int[100];
        int j = 1;
        for(int i = 0; i < mediumNullsForUnsorted.length-3; i++){
            
            mediumNullsForUnsorted[i] = j;
            j++;
        }
        //1000 elem array with null/0 values at end
        int[] largeNullsForUnsorted = new int[1000];
        int f = 1;
         for(int i = 0; i < largeNullsForUnsorted.length-3; i++){
             
            largeNullsForUnsorted[i] = f;
            f++;
         }
         
         
         int[] smallForSorted = {0,1,2,3,4,5,6,7,8,9};
        
        //100 elem array, for loop to produce values
        int[] mediumForSorted = new int[100];
        for(int i = 0; i < mediumForSorted.length; i++){
            mediumForSorted[i] = i;
        }
        //1000 elem array, for loop to produce values
        int[] largeForSorted = new int[1000];
         for(int i = 0; i < largeForSorted.length; i++){
            largeForSorted[i] = i;
        }
        
        // 10 elem array with null/0 values at end
        int[] smallNullsForSorted = new int[10];
        int r = 1;
        for(int i = 0; i < smallNullsForSorted.length-3; i++){ 
            smallNullsForSorted[i] = r;
            r++;
            
            
        }
        //100 elem array with null/0 values at end
        int[] mediumNullsForSorted = new int[100];
        int p = 1;
        for(int i = 0; i < mediumNullsForSorted.length-3; i++){
            
            mediumNullsForSorted[i] = p;
            p++;
        }
        //1000 elem array with null/0 values at end
        int[] largeNullsForSorted = new int[1000];
        int q = 1;
         for(int i = 0; i < largeNullsForSorted.length-3; i++){
             
            largeNullsForSorted[i] = q;
            q++;
         }
         
        System.out.println("UNSORTED ARRAYS " + "\n" + "_____________________");
        
       //Unsorted Fetch - Looking for end values in array (worst case)
        System.out.println("Unsorted Fetch Small: ");
        //unsortedFetch(smallForUnsorted,9);
        System.out.println("Unsorted Fetch Medium: ");
        //unsortedFetch(mediumForUnsorted,99);
        System.out.println("Unsorted Fetch Large: ");
        //unsortedFetch(largeForUnsorted,999);
        
        
        //Unsorted Inserts - Inserting to null values at end (worse case)
        System.out.println("Unsorted Insert Small: ");
        //unsortedInsert(smallNullsForUnsorted);
        System.out.println("Unsorted Insert medium: ");
        //unsortedInsert(mediumNullsForUnsorted);
        System.out.println("Unsorted Insert large: ");
        //unsortedInsert(largeNullsForUnsorted);
        
        //Unsorted Delete - Deleting first value (worse case)
        System.out.println("Unsorted Delete Small: ");
        //unsortedDelete(smallForUnsorted,1);
        System.out.println("Unsorted Delete Medium: ");
        //unsortedDelete(mediumForUnsorted,1);
        System.out.println("Unsorted Delete Large: ");
        //unsortedDelete(largeForUnsorted,1);
        
        System.out.println("END OF UNSORTED ARRAYS" + "\n" + "_________________");
        
        
        System.out.println("SORTED ARRAYS" + "\n" + "_________________");
        
        System.out.println("Sorted Fetch Small: ");
        //sortedFetch(smallForSorted,1);
        System.out.println("Sorted Fetch Medium: ");
        //sortedFetch(mediumForSorted,1);
        System.out.println("Sorted Fetch Large: ");
        //sortedFetch(largeForSorted,1);
        
        System.out.println("Sorted Insert Small: ");
        sortedInsert(smallNullsForSorted,1);
        System.out.println("Sorted Insert Medium: ");
        //sortedInsert(mediumNullsForSorted,1);
        System.out.println("Sorted Insert Large: ");
        //sortedInsert(largeNullsForSorted,1);
        
        System.out.println("Sorted Delete Small: ");
        //sortedDelete(smallForSorted,1);
        System.out.println("Sorted Delete Medium: ");
        //sortedDelete(mediumForSorted,1);
        System.out.println("Sorted Delete Large: ");
        //sortedDelete(largeForSorted,1);
        
        System.out.println("END");
    }
    
    
     public static void unsortedFetch(int[] array, int targetKey){
         //Checks for position of number we are looking for in array
         int i = 0;
         while(targetKey != array[i]){
             i++;
         }
        //Printing location found
        System.out.println(targetKey + " Found at location " + i);
}
     public static void unsortedInsert(int[] array){
        
        int targetKey = 84; //Random number to insert
        
        //runs through array values until 0/null value is found
        int i = 0;
        while(array[i] != 0){
          i++;  
        }    
        array[i] = targetKey;//inserts at null value
        //Print
        System.out.println(targetKey + " Inserted at location " + i);
        
     }
     
     public static void unsortedDelete(int[] array, int targetKey){
 
         int i =0;
         
         int next = array.length;//array length
         
         //i becomes location of target # to remove
         while(array[i] != targetKey){
             i++;
         }
         
         //j set to i, all values past key are pushed up one location
          for(int j = i; j < next - 1; j++){
             array[j] = array[j + 1];   
             
         }
         array[array.length-1] = 0;
         //print
         System.out.println("Array with value " + targetKey + " Removed: ");
         //loop to print values of array to show removal
         for(int k = 0; k < array.length; k++){
             
             System.out.print(" " + array[k] + "\n");
         }
         
         
     }
     
     public static void sortedFetch(int[] array, int targetKey){
         int low = 0;//low value
         int high = array.length - 1 ; //high value
         int i; 
         
         i = (low + high) / 2; //combines high and low to find mid point
         
         while(targetKey != array[i])
         {
             
             if(targetKey < array[i] && high != low)
             {
                 high = i - 1;//move high down
                
             }
             else
             {
                 low = i + 1; //move low up
                 
             }
            i = (low + high) / 2;
         }
         System.out.println(array[i] + " found at position: "  + i);
         
         }
     
     public static void sortedDelete(int[] array,int targetKey){
         int low = 0;//low value
         int high = array.length - 1 ;//high value
         int i;
         
         i = (low + high) / 2; //combines high and low to find mid point
         
         while(targetKey != array[i])
         {
             
             if(targetKey < array[i] && high != low)
             {
                 high = i - 1;//move high down
                
             }
             else
             {
                 low = i + 1;//move low up
                 
             }
            i = (low + high) / 2; // find midpoint
         }
         
         
         int next = array.length; //array length
         //move all elements up
         //j set to I all elements are pushed up
        for(int j = i; j < next - 1; j++){
             array[j] = array[j + 1];   
             
         }
        array[array.length-1] = 0;//sets end value to null/0
        System.out.println("Array with value " + targetKey + " Removed: ");
         //loop to print values of array to show removal
         for(int k = 0; k < array.length; k++){
             
             System.out.print(" " + array[k] + "\n");
         }
         
         
       
}
     public static void sortedInsert(int[] array, int targetKey){
         int low = 0;//low value
         int high = array.length - 4 ;//high value, removed 0 values
         int i;
         
         i = (low + high) / 2; //midpoint
         
         if(targetKey < array[high] ){
         
          while(targetKey != array[i])
         {
             
             if(targetKey < array[i] && high != low)
             {
                 high = i - 1;
                
             }
             else
             {
                 low = i + 1;
                 
             }
            i = (low + high) / 2;
         }
         
          
         for(int j = array.length-3; j >= i; j--){
             if(j-1 == -1){//avoid exception if insert is 1
                array[j] = array[j];
             }
             else{
             array[j] = array[j-1];
             }
         }
         array[i] = targetKey;
         System.out.println(array[i] + " found at position: "  + i);
             
         }
         else{
             array[high + 1] = targetKey;
         }
         
         System.out.println("Array with value " + targetKey + " inserted: ");
         //loop to print values of array to show removal
         for(int k = 0; k < array.length; k++){
             
             System.out.print(" " + array[k] + "\n");
         }
         }
     }
     
     



