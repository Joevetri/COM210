/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com210lab;

import javax.swing.JOptionPane;

/**
 *
 * @author jvetri
 */
public class problem2 {
    
    public static void main(String[] args){
        String[] items= new String[3];
        double[] prices=new double[3];
        double money=0;
        for(int i=0; i<3; i++)
        {
          String s=JOptionPane.showInputDialog("Please enter an item");
          items[i]=s;
          String t=JOptionPane.showInputDialog("Please enter the item's price");
          money=Double.parseDouble(t);
          prices[i]=money;
          System.out.println(items[i] + " " + prices[i]);
        }    
        double average;
        average=(prices[0] + prices[1] + prices[2])/3;
        
        if(items[0].equalsIgnoreCase("peas") || items[1].equalsIgnoreCase("peas") || items[2].equalsIgnoreCase("peas"))
        {
            System.out.println("The average price is $" + average);
        }  
        else
        {
            System.out.println("No average output");
        }    
       
    
    }
}
