/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com210lab;

import javax.swing.JOptionPane;

/**
 *
 * @author jvetri
 */
public class problem3 {
    
    public static void main(String[] args){
    
    String s=JOptionPane.showInputDialog("Enter the number of items");
        int f=Integer.parseInt(s);
        String[] items=new String[f];
        double price[]=new double[f];
        
        for(int i=0; i<f; i++)
        {
          String p=JOptionPane.showInputDialog("Please enter an item");
          items[i]=p;
          String t=JOptionPane.showInputDialog("Please enter the item's price");
          double money=Double.parseDouble(t);
          price[i]=money;
          System.out.println(items[i] + " " + price[i]);
        }
        double average;
        average=(price[0] + price[1] + price[2])/3;
        
          if(items[0].equalsIgnoreCase("peas") || items[1].equalsIgnoreCase("peas") || items[2].equalsIgnoreCase("peas"))
        {
            System.out.println("The average price is $" + average);
        }  
        else
        {
            System.out.println("No average output");
        }
          
       for(int t=f-1; t>=0; t--)
       {
           System.out.println(items[t] + " $" + price[t] );
       }    
       
    }
    
}
