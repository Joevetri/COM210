/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3.delimiter;

/**
 *
 * @author jvetri
 */
public class isEven {

    private int maxSize;
    private long[] stackArray;
    private int top;

    public isEven(int s) {
        maxSize = s;
        stackArray = new long[maxSize];
        top = -1;
    }

    public void push(long j) {
        // ++top instead of top++ because ++top means increment before excecuting the statement
        stackArray[++top] = j;
    }

    public long pop() {
        //
        return stackArray[top--];
    }

    public boolean isEmpty() {
        return (top == -1);
    }

    public boolean isFull() {
        return (top == maxSize - 1);
    }

    public static void main(String[] args) {
        //test string to see if program is working
        String test = ")((a(b(c)d)e))(";
        
        //isEven object with test.length as its parameter - - int S
        //which is maxsize
        isEven delimiter = new isEven(test.length());
        
        //String converted to char array using
        //.toCharArray() method
        char[] array = test.toCharArray();

       
            //for loop that runs 1 less than length of array (indexing)
            //increments by 1.
            for (int i = 0; i < test.length(); i++) {
                //uses i value as place in array and checks for present char
                //if location i contains '(' the push method is called
                if (array[i] == '(') {
                    delimiter.push(1);
                    //otherwise, if location i contains ')'
                    // call the pop method
                } else if (array[i] == ')') {
                    //if delimiter isEmpty() is used because unbalanced ) parenthesis
                    //will cause index out of bounds exception
                    //if true -- terminate program
                    if(delimiter.isEmpty() == true){
                        System.out.println(test);
                        System.out.println("String is unbalanced");
                        System.exit(0);
                    }
                    //if isEmpty() is not true -- pop
                    //loop continues
                    else{
                    delimiter.pop();
                    }
                }
            }
            //if outside of loop and stack is empty then the string
            //must be balanced
            if (delimiter.isEmpty() == true) {
                System.out.println(test);
                System.out.println("String is balanced");
            }
            //still necessary for if ( is unbalanced
            if (delimiter.isEmpty() == false) {
                System.out.println(test);
                System.out.println("String is unbalanced");
            }
        } 

    }

